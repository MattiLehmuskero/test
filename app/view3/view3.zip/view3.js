'use strict';

angular.module('myApp.view3', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
  $routeProvider.when('/view3', {
    templateUrl: 'view3/view3.html',
    controller: 'View3Ctrl'
  });
}])

.controller('View3Ctrl', ['$scope', function($scope) {
  $scope.fuelItem = {
	date : 0,
	litres : 0,
	mileage : 0,
	totalMileage : 0};

  $scope.fuelArray = [];
  
  $scope.storeItem = function(){
	var item = {date: $scope.fuelItem.date,
	litres: $scope.fuelItem.litres,
	mileage: $scope.fuelItem.mileage,
	totalMileage: $scope.fuelItem.totalMileage
	};
	return item;
  }
  
  $scope.save = function()  {
	$scope.fuelArray.push($scope.storeItem());
	alert(JSON.stringify($scope.fuelArray));
  };
  
  $scope.load = function()  {
	$scope.fuelArray = JSON.parse(localStorage.fuelArray);
  };
  
  $scope.store = function() {
	localStorage.fuelArray = JSON.stringify($scope.fuelArray);
  };
  
  $scope.reset = function() {
	localStorage.fuelArray = [];
  };
}]);